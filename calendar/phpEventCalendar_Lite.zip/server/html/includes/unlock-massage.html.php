<div style="padding:10px;background: #333333;color:red">
    Available only in full version - <a href="http://phpeventcalendar.com/store/?ref=lite" target="_new" style="text-decoration:underline">UNLOCK THIS FEATURE</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <button type="button" data-dismiss="modal" aria-hidden="true">Back</button>
</div>