<!-- Search Calendar -->
<div id="search-calendar" style="clear: both; text-align: left">
    <div></div>
</div>
<!-- Search Calendar Ends-->
